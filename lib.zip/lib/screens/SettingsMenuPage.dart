
import 'package:flutter/material.dart';
import 'settings_page.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsMenuPage extends StatelessWidget {
  const SettingsMenuPage({super.key});

  static const String _privacyUrl =
      'https://doc-hosting.flycricket.io/work-reminder-privacy-policy/9e71390e-a8a6-4dd4-a8f8-d7b873487e9f/privacy';
  static const String _termsUrl =
      'https://doc-hosting.flycricket.io/work-reminder-terms-of-use/1eff1294-bfa4-4836-a8c6-85f83985dc81/terms';
  static const String _supportUrl =
      'https://www.instagram.com/work_reminder/?igsh=MXFxNTdhZmR3Z3BvZw%3D%3D&utm_source=qr#';

  Future<void> _openUrl(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    try {
      if (await canLaunchUrl(uri)) {
        final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (!launched) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تعذّر فتح الرابط. الرجاء المحاولة مرة أخرى.')),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('الرابط غير صالح.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('حدث خطأ أثناء فتح الرابط: $e')),
      );
    }
  }

  Widget _buildItem(
      BuildContext context, {
        required IconData icon,
        required String title,
        String? subtitle,
        required VoidCallback onTap,
      }) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(12),
      color: Theme.of(context).cardColor,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 22,
                child: Icon(icon, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    if (subtitle != null) const SizedBox(height: 6),
                    if (subtitle != null)
                      Text(subtitle, style: const TextStyle(fontSize: 13)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left, size: 24),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الإعدادات العامة'),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: ListView(
              children: [
                _buildItem(
                  context,
                  icon: Icons.schedule,
                  title: 'إعدادات الدوام',
                  subtitle: 'ضبط نظام العمل، أوقات البداية والإثبات، والتذكير',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SettingsPage()),
                    );
                  },
                ),
                const SizedBox(height: 12),

                _buildItem(
                  context,
                  icon: Icons.privacy_tip,
                  title: 'سياسة الخصوصية',
                  subtitle: 'عرض سياسة الخصوصية للتطبيق',
                  onTap: () => _openUrl(context, _privacyUrl),
                ),
                const SizedBox(height: 12),

                _buildItem(
                  context,
                  icon: Icons.description,
                  title: 'شروط الاستخدام',
                  subtitle: 'عرض الشروط والأحكام الخاصة بالتطبيق',
                  onTap: () => _openUrl(context, _termsUrl),
                ),
                const SizedBox(height: 12),

                _buildItem(
                  context,
                  icon: Icons.support_agent,
                  title: 'الدعم والتواصل',
                  subtitle: 'تواصل معنا لأي استفسار أو دعم',
                  onTap: () => _openUrl(context, _supportUrl),
                ),

                const SizedBox(height: 18),

                // ملاحظة / تذييل صغير
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.06),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
