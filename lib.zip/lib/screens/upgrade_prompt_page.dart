// lib/screens/upgrade_prompt_page.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:khamsat/main.dart';
import 'package:khamsat/service/purchase%20Manager.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent_plus/android_intent.dart';

class UpgradePromptPage extends StatelessWidget {
  const UpgradePromptPage({super.key});

  Future<void> _openStore(BuildContext context) async {
    try {
      final pkg = await PackageInfo.fromPlatform();
      final packageName = pkg.packageName;

      if (defaultTargetPlatform == TargetPlatform.android) {
        // محاولة فتح Google Play عبر Intent أولاً
        final playUrl = 'https://play.google.com/store/apps/details?id=$packageName';
        try {
          final intent = AndroidIntent(action: 'action_view', data: playUrl);
          await intent.launch();
          return;
        } catch (e) {
          debugPrint('[UpgradePrompt] Android Intent failed -> $e');
        }

        // fallback باستخدام url_launcher
        final uri = Uri.parse(playUrl);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
          return;
        }
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        // استبدل THIS_APPLE_ID برقم تطبيقك (مثلاً: 123456789)
        const appleId = 'YOUR_APPLE_APP_ID';
        final itmsUri = Uri.parse('itms-apps://itunes.apple.com/app/id$appleId');
        final httpsUri = Uri.parse('https://apps.apple.com/app/id$appleId');

        if (await canLaunchUrl(itmsUri)) {
          await launchUrl(itmsUri, mode: LaunchMode.externalApplication);
          return;
        } else if (await canLaunchUrl(httpsUri)) {
          await launchUrl(httpsUri, mode: LaunchMode.externalApplication);
          return;
        }
      } else {
        // generic fallback
        final url = 'https://play.google.com/store/apps/details?id=$packageName';
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e, st) {
      debugPrint('[UpgradePrompt] _openStore error -> $e\n$st');
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فشل فتح المتجر. حاول مرة أخرى.'), duration: Duration(seconds: 2)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الترقية للوصول الكامل'),
        automaticallyImplyLeading: false, // منع الرجوع
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 40),
            const Icon(Icons.lock_open, size: 96),
            const SizedBox(height: 20),
            const Text(
              'انتهت فترة التجربة المجانية',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            const Text(
              'لاستمرار استقبال الإشعارات والوصول الكامل للمميزات، الرجاء الترقية الآن.',
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () => _openStore(context),
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14.0, horizontal: 10.0),
                child: Text('اشترِ الآن', style: TextStyle(fontSize: 16)),
              ),
              style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () async {
                await PurchaseManager.instance.markShowUpgradeOnLaunch(false);
                if (Navigator.canPop(context)) {
                  Navigator.of(context).pop();
                } else {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const CalendarLauncher()));
                }
              },
              child: const Text('لاحقًا'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
