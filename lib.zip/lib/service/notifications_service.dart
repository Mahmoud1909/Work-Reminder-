// lib/service/notifications_service.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart' show debugPrint, kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import '../service/purchase%20Manager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

// Optional VacationManager import (keep a stub if not implemented in your app)
import '../screens/vacation_manager.dart';

@pragma('vm:entry-point')
Future<bool> workManagerBackgroundHandler(String taskName, Map<String, dynamic>? inputData) async {
  // Ensure isolate init
  try {
    WidgetsFlutterBinding.ensureInitialized();
  } catch (_) {}

  try {
    tzdata.initializeTimeZones();
    debugPrint('[WM][handler] tz DB initialized');
  } catch (e, st) {
    debugPrint('[WM][handler] tz init error -> $e\n$st');
  }

  debugPrint('[WM][handler] invoked task=$taskName inputData=$inputData');

  try {
    await NotificationsService.initialize();
    debugPrint('[WM][handler] NotificationsService initialized');

    if (taskName == 'khamsat_show_test_notification') {
      await NotificationsService.instance.showImmediateNotification(
        id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
        title: 'اختبار إشعار (WorkManager)',
        body: 'اختبار عبر WorkManager',
        payload: 'workmanager_test',
      );
    } else {
      await NotificationsService.instance.rescheduleIfNeeded(force: false);
    }
  } catch (e, st) {
    debugPrint('[WM][handler] error while handling task -> $e\n$st');
  }

  return true;
}

@pragma('vm:entry-point')
void _notificationTapBackground(NotificationResponse response) {
  try {
    debugPrint('[BG_NOTIFY_CALLBACK] payload=${response.payload}');
    // calling private method on instance is fine inside same library
    NotificationsService.instance._handleNotificationResponse(response);
  } catch (e, st) {
    debugPrint('[BG_NOTIFY_CALLBACK] error -> $e\n$st');
  }
}

class NotificationsService {
  NotificationsService._privateConstructor();
  static final NotificationsService instance = NotificationsService._privateConstructor();

  static Future<void> initialize() async => await NotificationsService.instance.init();

  static const MethodChannel _nativeChannel = MethodChannel('khamsat/native_notifications');

  // SharedPreferences keys
  static const String _kWorkSystem = 'workSystem';
  static const String _kStartDate = 'startDate';
  static const String _kMorningStart = 'morningStart';
  static const String _kMorningCheckIn = 'morningCheckIn';
  static const String _kAfternoonStart = 'afternoonStart';
  static const String _kAfternoonCheckIn = 'afternoonCheckIn';
  static const String _kNightStart = 'nightStart';
  static const String _kNightCheckIn = 'nightCheckIn';
  static const String _kReminder = 'reminder';
  static const String _kMaintenanceInterval = 'maintenanceInterval';
  static const String _kScheduledUntilKey = 'notifications_scheduled_until';
  static const String _kWelcomeShownKey = 'welcomeNotificationShown';
  static const String _kConfirmationShownKey = 'notifications_confirmed_by_notification';
  static const String _kLastKnownTimeZone = 'lastKnownTimeZone';
  static const String _kSubscriptionReminderScheduled = 'subscription_reminder_scheduled';
  static const String _kSubscriptionReminderCancelled = 'subscription_reminder_cancelled';

  static const int _kSubscriptionReminderId = 450000;


  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  GlobalKey<NavigatorState>? _navigatorKey;
  void setNavigatorKey(GlobalKey<NavigatorState> key) {
    _navigatorKey = key;
    debugPrint('[NotificationsService] navigatorKey set');
  }

  bool _initialized = false;
  String? _lastKnownTimeZone;

  Future<void> init() async {
    if (_initialized) {
      debugPrint('[NotificationsService.init] already initialized -> returning');
      return;
    }
    debugPrint('[NotificationsService.init] start');

    await _initTimezone();

    const androidInitSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInitSettings = DarwinInitializationSettings();

    final initSettings = InitializationSettings(android: androidInitSettings, iOS: iosInitSettings);

    try {
      await flutterLocalNotificationsPlugin.initialize(
        initSettings,
        onDidReceiveNotificationResponse: (NotificationResponse response) {
          debugPrint('[NotificationsService.init] notification response payload=${response.payload}');
          _handleNotificationResponse(response);
        },
        // important: handle taps when app is in background / terminated
        onDidReceiveBackgroundNotificationResponse: _notificationTapBackground,
      );
      debugPrint('[NotificationsService.init] plugin initialized');
    } catch (e, st) {
      debugPrint('[NotificationsService.init] plugin init error -> $e\n$st');
    }

    if (!kIsWeb && Platform.isAndroid) {
      try {
        final androidImpl = flutterLocalNotificationsPlugin
            .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

        if (androidImpl != null) {
          // قناة تذكير الاشتراك / الشراء 💎
          final purchaseChannel = AndroidNotificationChannel(
            'purchase_channel',
            'Purchase Reminders',
            description: 'Subscription / purchase reminders',
            importance: Importance.max,
            playSound: true,
            showBadge: true,
          );
          await androidImpl.createNotificationChannel(purchaseChannel);

          // قناة التذكير بالعمل ⏰
          final workChannel = AndroidNotificationChannel(
            'work_channel',
            'Work Reminders',
            description: 'Work reminder notifications',
            importance: Importance.max,
            playSound: true,
            showBadge: true,
          );

          // قناة الترحيب أول تشغيل 🎉
          final firstRunChannel = AndroidNotificationChannel(
            'first_run_channel',
            'First Run Notifications',
            description: 'One-time first-run / welcome notifications',
            importance: Importance.max,
            playSound: true,
            showBadge: true,
          );

          await androidImpl.createNotificationChannel(workChannel);
          await androidImpl.createNotificationChannel(firstRunChannel);

          debugPrint('[NotificationsService.init] Android channels created');
        }
      } catch (e, st) {
        debugPrint('[NotificationsService.init] createNotificationChannel error -> $e\n$st');
      }
    }

    try {
      final tzName = (await FlutterTimezone.getLocalTimezone()).toString();
      _lastKnownTimeZone = tzName;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kLastKnownTimeZone, tzName);
      debugPrint('[NotificationsService.init] timezone snapshot saved -> $tzName');
    } catch (e) {
      debugPrint('[NotificationsService.init] reading tz snapshot failed -> $e');
    }

    _initialized = true;
    debugPrint('[NotificationsService.init] finished');
  }

  Future<void> _initTimezone() async {
    debugPrint('[NotificationsService._initTimezone] init tz data');
    tzdata.initializeTimeZones();

    final prefs = await SharedPreferences.getInstance();
    String tzName = 'UTC';

    try {
      final dynamic tzResult = await FlutterTimezone.getLocalTimezone();
      if (tzResult is String) tzName = tzResult;
      else if (tzResult != null) tzName = tzResult.toString();
    } catch (e) {
      debugPrint('[NotificationsService._initTimezone] FlutterTimezone failed -> $e');
    }

    try {
      tz.setLocalLocation(tz.getLocation(tzName));
      _lastKnownTimeZone = tzName;
      await prefs.setString(_kLastKnownTimeZone, tzName);
      debugPrint('[NotificationsService._initTimezone] set tz to $tzName');
      return;
    } catch (e) {
      debugPrint('[NotificationsService._initTimezone] tz.getLocation failed for $tzName -> $e');
    }

    try {
      final persisted = prefs.getString(_kLastKnownTimeZone);
      if (persisted != null && persisted.isNotEmpty) {
        tz.setLocalLocation(tz.getLocation(persisted));
        _lastKnownTimeZone = persisted;
        debugPrint('[NotificationsService._initTimezone] used persisted tz -> $persisted');
        return;
      }
    } catch (e) {
      debugPrint('[NotificationsService._initTimezone] persisted tz failed -> $e');
    }

    const fallbackCandidates = ['Africa/Cairo', 'Etc/GMT-3', 'Europe/Athens', 'UTC'];
    for (final c in fallbackCandidates) {
      try {
        tz.setLocalLocation(tz.getLocation(c));
        _lastKnownTimeZone = c;
        await prefs.setString(_kLastKnownTimeZone, c);
        debugPrint('[NotificationsService._initTimezone] fallback success -> $c');
        return;
      } catch (_) {}
    }

    tz.setLocalLocation(tz.getLocation('UTC'));
    _lastKnownTimeZone = 'UTC';
    try { await prefs.setString(_kLastKnownTimeZone, 'UTC'); } catch (_) {}
    debugPrint('[NotificationsService._initTimezone] used final fallback UTC');
  }

  // ---------------- permissions helpers ----------------
  Future<bool> requestPermissions() async {
    try {
      if (!kIsWeb && Platform.isIOS) {
        final iosImpl = flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
        if (iosImpl != null) await iosImpl.requestPermissions(alert: true, badge: true, sound: true);
      }

      if (!kIsWeb && Platform.isAndroid) {
        try {
          final status = await Permission.notification.status;
          if (!status.isGranted) {
            final res = await Permission.notification.request();
            return res.isGranted;
          }
          return true;
        } catch (e) {
          debugPrint('[NotificationsService.requestPermissions] permission_handler error -> $e');
          return false;
        }
      }
      return true;
    } catch (e, st) {
      debugPrint('[NotificationsService.requestPermissions] error -> $e\n$st');
      return false;
    }
  }

  Future<void> requestExactAlarmPermissionIfNeeded() async {
    if (!kIsWeb && Platform.isAndroid) {
      try {
        await _nativeChannel.invokeMethod('requestScheduleExactAlarm');
      } catch (e) {
        debugPrint('[NotificationsService] native requestScheduleExactAlarm not implemented -> $e');
      }
    }
  }

  Future<void> requestIgnoreBatteryOptimizationsIfNeeded() async {
    if (!kIsWeb && Platform.isAndroid) {
      try {
        await _nativeChannel.invokeMethod('requestIgnoreBatteryOptimizations');
      } catch (e) {
        debugPrint('[NotificationsService] native requestIgnoreBatteryOptimizations not implemented -> $e');
      }
    }
  }

  Future<void> openAppNotificationSettings() async {
    if (!kIsWeb && Platform.isAndroid) {
      try {
        await _nativeChannel.invokeMethod('openNotificationSettings');
        return;
      } catch (e) {
        debugPrint('[NotificationsService] openNotificationSettings native not implemented -> $e');
      }
    }
    try { await openAppSettings(); } catch (e) { debugPrint('[NotificationsService] openAppSettings failed -> $e'); }
  }

  // ---------------- compatibility helpers (used by SettingsPage older calls) ----------------
  Future<void> scheduleOneOffSecondsFromNow({required int id, required String title, required String body, required int seconds}) async {
    final scheduledLocal = DateTime.now().add(Duration(seconds: seconds));
    await scheduleNotification(id: id, title: title, body: body, scheduledDateTimeLocal: scheduledLocal, payload: 'oneoff|$id');
  }

  Future<void> scheduleOneOffMinutesFromNow({required int id, required String title, required String body, required int minutes}) async {
    final scheduledLocal = DateTime.now().add(Duration(minutes: minutes));
    await scheduleNotification(id: id, title: title, body: body, scheduledDateTimeLocal: scheduledLocal, payload: 'oneoff|$id');
  }

  Future<void> scheduleDailyAtTime({required int id, required String title, required String body, required int hour, required int minute, String channelId = 'work_channel'}) async {
    final now = tz.TZDateTime.now(tz.local);
    var first = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (!first.isAfter(now)) first = first.add(const Duration(days: 1));
    final nd = NotificationDetails(android: AndroidNotificationDetails(channelId, channelId == 'work_channel' ? 'Work Reminders' : 'General', channelDescription: 'Daily reminders', importance: Importance.max, priority: Priority.high, playSound: true), iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true));
    await flutterLocalNotificationsPlugin.zonedSchedule(id, title, body, first, nd, payload: 'daily|$hour:$minute', androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, matchDateTimeComponents: DateTimeComponents.time);
  }

  // ---------------- helpers: ids / titles / bodies ----------------
  int _notificationIdFor(DateTime dayUtc, int offset, [String? tag]) {
    final baseSeconds = DateTime.utc(dayUtc.year, dayUtc.month, dayUtc.day).millisecondsSinceEpoch ~/ 1000;
    int salt = 0;
    if (tag != null && tag.isNotEmpty) {
      final hashBytes = sha1.convert(utf8.encode(tag)).bytes;
      salt = ((hashBytes[0] << 16) | (hashBytes[1] << 8) | hashBytes[2]) & 0x00FFFFFF;
      salt = salt % 100000;
    }
    final idLarge = ((baseSeconds % 1000000) * 10) + offset + salt;
    return idLarge % 0x7FFFFFFF;
  }

  String _titleForOffset(int offset, String shift) {
    switch (offset) {
      case 0: return 'تذكير قبل 12 ساعة';
      case 1: return 'تذكير: بداية نوبة $shift';
      case 2: return 'تأكيد حضور: $shift';
      case 3: return 'انتهاء نوبة: $shift';
      default: return 'تذكير';
    }
  }

  String _bodyForOffset(int offset, String shift) {
    switch (offset) {
      case 0: return 'لديك نوبة $shift بعد 12 ساعة.';
      case 1: return 'نوبة $shift ستبدأ قريبًا.';
      case 2: return 'حان وقت إثبات الحضور لنوبة $shift.';
      case 3: return 'من المفترض أن تكون نوبة $shift قد انتهت الآن.';
      default: return '';
    }
  }

  // ---------------- schedule single notification ----------------
  Future<void> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDateTimeLocal,
    String? payload,
    AndroidNotificationDetails? androidDetails,
    DarwinNotificationDetails? iosDetails,
    String channelId = 'work_channel',
    DateTimeComponents? matchDateTimeComponents,
  }) async {
    debugPrint('[scheduleNotification] id=$id title=$title scheduledLocal=$scheduledDateTimeLocal');
    try {
      await init();

      final scheduledTz = tz.TZDateTime(tz.local, scheduledDateTimeLocal.year, scheduledDateTimeLocal.month, scheduledDateTimeLocal.day, scheduledDateTimeLocal.hour, scheduledDateTimeLocal.minute, scheduledDateTimeLocal.second, scheduledDateTimeLocal.millisecond);

      final now = tz.TZDateTime.now(tz.local);
      if (!scheduledTz.isAfter(now) && matchDateTimeComponents == null) {
        debugPrint('[scheduleNotification] skipping past notification id=$id scheduled=$scheduledTz now=$now');
        return;
      }

      final nd = NotificationDetails(
        android: androidDetails ?? AndroidNotificationDetails(channelId, channelId == 'work_channel' ? 'Work Reminders' : 'General', channelDescription: channelId == 'work_channel' ? 'Work reminder notifications' : 'General notifications', importance: Importance.max, priority: Priority.high, playSound: true),
        iOS: iosDetails ?? const DarwinNotificationDetails(presentAlert: true, presentSound: true),
      );

      try {
        await flutterLocalNotificationsPlugin.zonedSchedule(
          id,
          title,
          body,
          scheduledTz,
          nd,
          payload: payload,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          matchDateTimeComponents: matchDateTimeComponents,
        );
        debugPrint('[scheduleNotification] scheduled id=$id at $scheduledTz');
      } on PlatformException catch (pe) {
        debugPrint('[scheduleNotification] PlatformException -> $pe, trying inexact fallback');
        try {
          await flutterLocalNotificationsPlugin.zonedSchedule(
            id,
            title,
            body,
            scheduledTz,
            nd,
            payload: payload,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            matchDateTimeComponents: matchDateTimeComponents,
          );
          debugPrint('[scheduleNotification] scheduled inexact id=$id at $scheduledTz');
        } catch (e2, st2) {
          debugPrint('[scheduleNotification] inexact retry failed -> $e2\n$st2');
          await _scheduleNativeFallback(id, title, body, scheduledDateTimeLocal);
        }
      } catch (e, st) {
        debugPrint('[scheduleNotification] unexpected error -> $e\n$st');
        await _scheduleNativeFallback(id, title, body, scheduledDateTimeLocal);
      }
    } catch (e, st) {
      debugPrint('[scheduleNotification] outer error -> $e\n$st');
    }
  }

  Future<void> _scheduleNativeFallback(int id, String title, String body, DateTime scheduledLocal) async {
    try {
      final delaySeconds = scheduledLocal.difference(DateTime.now()).inSeconds.clamp(5, 2147483647);
      if (delaySeconds <= 0) {
        await showImmediateNotification(id: id, title: title, body: body, payload: 'fallback_immediate');
        return;
      }

      if (!kIsWeb && Platform.isAndroid) {
        try {
          await _nativeChannel.invokeMethod('scheduleFallbackAlarm', {'id': id, 'title': title, 'body': body, 'delaySeconds': delaySeconds});
          return;
        } catch (e) {
          debugPrint('[nativeFallback] native invoke failed -> $e');
        }
      }

      await showImmediateNotification(id: id, title: title, body: body, payload: 'fallback_immediate');
    } catch (e, st) {
      debugPrint('[nativeFallback] error -> $e\n$st');
    }
  }

  Future<void> showImmediateNotification({required int id, required String title, required String body, String? payload}) async {
    try {
      final details = NotificationDetails(
        android: AndroidNotificationDetails('work_channel', 'Work Reminders', channelDescription: 'Work reminder notifications', importance: Importance.max, priority: Priority.high),
        iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true),
      );
      await flutterLocalNotificationsPlugin.show(id, title, body, details, payload: payload);
      debugPrint('[showImmediateNotification] shown id=$id');
    } catch (e, st) {
      debugPrint('[showImmediateNotification] error -> $e\n$st');
    }
  }

  // ---------------- scheduleNotificationsForDayLocal ----------------
  Future<void> scheduleNotificationsForDayLocal({required DateTime localDay}) async {
    final day = DateTime(localDay.year, localDay.month, localDay.day);
    debugPrint('[scheduleNotificationsForDayLocal] day=$day START');
    try {
      try {
        final vac = await VacationManager.getVacationForDate(day);
        if (vac != null) return;
      } catch (e) {
        debugPrint('[scheduleNotificationsForDayLocal] VacationManager check failed -> $e');
      }

      final prefs = await SharedPreferences.getInstance();
      final workSystem = prefs.getString(_kWorkSystem) ?? 'صباحي';
      final maintenanceInterval = prefs.getInt(_kMaintenanceInterval) ?? 0;

      final morningStart = prefs.getString(_kMorningStart) ?? '07:00 صباحاً';
      final morningCheckIn = prefs.getString(_kMorningCheckIn) ?? '07:30 صباحاً';
      final afternoonStart = prefs.getString(_kAfternoonStart) ?? '15:00 مساءً';
      final afternoonCheckIn = prefs.getString(_kAfternoonCheckIn) ?? '15:30 مساءً';
      final nightStart = prefs.getString(_kNightStart) ?? '19:00 مساءً';
      final nightCheckIn = prefs.getString(_kNightCheckIn) ?? '19:30 مساءً';
      final reminderStr = prefs.getString(_kReminder) ?? 'نصف ساعة';
      final reminderDuration = _getReminderDurationFromString(reminderStr);

      final startDateStr = prefs.getString(_kStartDate);
      if (startDateStr == null) return;
      var startDate = DateTime.tryParse(startDateStr);
      if (startDate == null) return;
      startDate = DateTime(startDate.year, startDate.month, startDate.day);

      final schedule = _generateWorkScheduleSegment(workSystem, startDate, maintenanceInterval, days: 400);
      final keyUtc = DateTime.utc(day.year, day.month, day.day);
      final shift = schedule[keyUtc];
      if (shift == null || shift == 'راحة') return;

      DateTime startDT;
      DateTime checkInDT;
      if (shift == 'صبح' || shift == 'صيانة') {
        startDT = _parseTime(day, morningStart);
        checkInDT = _parseTime(day, morningCheckIn);
      } else if (shift == 'عصر') {
        startDT = _parseTime(day, afternoonStart);
        checkInDT = _parseTime(day, afternoonCheckIn);
      } else {
        startDT = _parseTime(day, nightStart);
        checkInDT = _parseTime(day, nightCheckIn);
      }

      final shiftDuration = _getShiftDurationFromSystem(workSystem);
      final endDT = startDT.add(shiftDuration);

      final Map<int, DateTime> times = {
        0: startDT.subtract(const Duration(hours: 12)),
        1: startDT.subtract(reminderDuration),
        2: checkInDT,
        3: endDT,
      };

      final dayUtc = DateTime.utc(day.year, day.month, day.day);

      for (final entry in times.entries) {
        final offset = entry.key;
        final scheduledLocal = entry.value;
        final id = _notificationIdFor(dayUtc, offset);
        try {
          final tzDt = tz.TZDateTime.from(scheduledLocal, tz.local);
          if (tzDt.isBefore(tz.TZDateTime.now(tz.local))) continue;
          final payload = '${dayUtc.toIso8601String()}|$offset|$shift';
          await scheduleNotification(id: id, title: _titleForOffset(offset, shift), body: _bodyForOffset(offset, shift), scheduledDateTimeLocal: scheduledLocal, payload: payload, channelId: 'work_channel');
        } catch (e, st) {
          debugPrint('[scheduleNotificationsForDayLocal] error scheduling offset=$offset -> $e\n$st');
        }
      }

      debugPrint('[scheduleNotificationsForDayLocal] finished for $day shift=$shift');
    } catch (e, st) {
      debugPrint('[scheduleNotificationsForDayLocal] outer error -> $e\n$st');
    }
  }

  // ---------------- ensure remaining notifications after check-in tap ----------------
  /// When user taps the "check-in" notification (offset == 2) we re-schedule any remaining
  /// notifications for that day (same strategy as scheduleNotificationsForDayLocal) so they
  /// will be delivered at their proper times (or fallback native if needed).
  Future<void> _ensureRemainingNotificationsForDay(DateTime localDay, String shift) async {
    try {
      final day = DateTime(localDay.year, localDay.month, localDay.day);
      debugPrint('[ensureRemaining] start for $day shift=$shift');

      final prefs = await SharedPreferences.getInstance();

      // read config
      final workSystem = prefs.getString(_kWorkSystem) ?? 'صباحي';
      final maintenanceInterval = prefs.getInt(_kMaintenanceInterval) ?? 0;
      final morningStart = prefs.getString(_kMorningStart) ?? '07:00 صباحاً';
      final morningCheckIn = prefs.getString(_kMorningCheckIn) ?? '07:30 صباحاً';
      final afternoonStart = prefs.getString(_kAfternoonStart) ?? '15:00 مساءً';
      final afternoonCheckIn = prefs.getString(_kAfternoonCheckIn) ?? '15:30 مساءً';
      final nightStart = prefs.getString(_kNightStart) ?? '19:00 مساءً';
      final nightCheckIn = prefs.getString(_kNightCheckIn) ?? '19:30 مساءً';
      final reminderStr = prefs.getString(_kReminder) ?? 'نصف ساعة';
      final reminderDuration = _getReminderDurationFromString(reminderStr);

      // determine start & checkin for this shift
      DateTime startDT;
      DateTime checkInDT;
      if (shift == 'صبح' || shift == 'صيانة') {
        startDT = _parseTime(day, morningStart);
        checkInDT = _parseTime(day, morningCheckIn);
      } else if (shift == 'عصر') {
        startDT = _parseTime(day, afternoonStart);
        checkInDT = _parseTime(day, afternoonCheckIn);
      } else {
        startDT = _parseTime(day, nightStart);
        checkInDT = _parseTime(day, nightCheckIn);
      }

      final shiftDuration = _getShiftDurationFromSystem(workSystem);
      final endDT = startDT.add(shiftDuration);

      final Map<int, DateTime> times = {
        0: startDT.subtract(const Duration(hours: 12)),
        1: startDT.subtract(reminderDuration),
        2: checkInDT,
        3: endDT,
      };

      final dayUtc = DateTime.utc(day.year, day.month, day.day);
      final now = DateTime.now();

      for (final entry in times.entries) {
        final offset = entry.key;
        final scheduledLocal = entry.value;

        // only schedule future notifications
        if (!scheduledLocal.isAfter(now)) {
          debugPrint('[ensureRemaining] offset=$offset scheduledLocal=$scheduledLocal <= now -> skipping');
          continue;
        }

        final id = _notificationIdFor(dayUtc, offset);

        try {
          // cancel any existing with same id to avoid duplicates
          await flutterLocalNotificationsPlugin.cancel(id);
        } catch (e) {
          debugPrint('[ensureRemaining] cancel(id=$id) failed -> $e');
        }

        try {
          final payload = '${dayUtc.toIso8601String()}|$offset|$shift';
          await scheduleNotification(
            id: id,
            title: _titleForOffset(offset, shift),
            body: _bodyForOffset(offset, shift),
            scheduledDateTimeLocal: scheduledLocal,
            payload: payload,
            channelId: 'work_channel',
          );
          debugPrint('[ensureRemaining] scheduled offset=$offset id=$id at $scheduledLocal');
        } catch (e, st) {
          debugPrint('[ensureRemaining] scheduleNotification offset=$offset failed -> $e\n$st');
        }
      }

      debugPrint('[ensureRemaining] finished for $day shift=$shift');
    } catch (e, st) {
      debugPrint('[ensureRemaining] outer error -> $e\n$st');
    }
  }

  // ---------------- scheduleNextNDays ----------------
  Future<void> scheduleNextNDays(int nDays) async {
    const int MAX_DAYS = 60;
    if (nDays <= 0) return;
    int days = nDays > MAX_DAYS ? MAX_DAYS : nDays;

    final prefs = await SharedPreferences.getInstance();
    final startDateStr = prefs.getString(_kStartDate);
    if (startDateStr == null) return;
    var startDate = DateTime.tryParse(startDateStr);
    if (startDate == null) return;
    startDate = DateTime(startDate.year, startDate.month, startDate.day);

    final workSystem = prefs.getString(_kWorkSystem) ?? 'صباحي';
    final maintenanceInterval = prefs.getInt(_kMaintenanceInterval) ?? 0;

    final scheduleMap = _generateWorkScheduleSegment(workSystem, startDate, maintenanceInterval, days: days + 365);

    List<Vacation> vacations = [];
    try { vacations = await VacationManager.getAllVacationsSorted(); } catch (e) { vacations = []; }

    try {
      if (!kIsWeb && Platform.isIOS) {
        final pending = await flutterLocalNotificationsPlugin.pendingNotificationRequests();
        final pendingCount = pending.length;
        final maxIOS = 60;
        final approxPerDay = 4;
        final allowedNew = (maxIOS - pendingCount) ~/ approxPerDay;
        if (allowedNew <= 0) return;
        if (allowedNew < days) days = allowedNew;
      }
    } catch (e) {
      debugPrint('[scheduleNextNDays] iOS pending check failed -> $e');
    }

    DateTime current = DateTime.now();
    current = DateTime(current.year, current.month, current.day);
    int scheduled = 0;
    int lookAhead = 0;
    final int safetyLimit = days + 365;

    while (scheduled < days && lookAhead < safetyLimit) {
      final day = current.add(Duration(days: lookAhead));
      final keyUtc = DateTime.utc(day.year, day.month, day.day);
      final shift = scheduleMap[keyUtc];

      bool isVacation = false;
      for (final vac in vacations) {
        final s = DateTime(vac.startDate.year, vac.startDate.month, vac.startDate.day);
        final e = DateTime(vac.endDate.year, vac.endDate.month, vac.endDate.day);
        if (!day.isBefore(s) && !day.isAfter(e)) { isVacation = true; break; }
      }
      if (isVacation) { lookAhead++; continue; }

      if (shift != null && shift != 'راحة') {
        try {
          await cancelNotificationsForDay(day);
          await scheduleNotificationsForDayLocal(localDay: day);
          scheduled++;
        } catch (e, st) {
          debugPrint('[scheduleNextNDays] error scheduling $day -> $e\n$st');
        }
      }
      lookAhead++;
    }

    final scheduledUntil = DateTime.now().add(Duration(days: lookAhead));
    try { await prefs.setString(_kScheduledUntilKey, scheduledUntil.toIso8601String()); } catch (e) {}
    debugPrint('[scheduleNextNDays] done scheduled_count=$scheduled scheduled_until=$scheduledUntil lookAhead=$lookAhead');
  }

  Future<DateTime?> getScheduledUntil() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_kScheduledUntilKey);
    if (s == null) return null;
    return DateTime.tryParse(s);
  }

  // ---------------- cancellations ----------------
  Future<void> cancelNotificationsForDay(DateTime localDay) async {
    final dayUtc = DateTime.utc(localDay.year, localDay.month, localDay.day);
    for (int offset = 0; offset < 4; offset++) {
      try {
        final id = _notificationIdFor(dayUtc, offset);
        await flutterLocalNotificationsPlugin.cancel(id);
      } catch (e) {}
    }
  }

  Future<void> cancelNotificationsForRange(DateTime startLocal, DateTime endLocal) async {
    var cur = DateTime(startLocal.year, startLocal.month, startLocal.day);
    final end = DateTime(endLocal.year, endLocal.month, endLocal.day);
    while (!cur.isAfter(end)) {
      await cancelNotificationsForDay(cur);
      cur = cur.add(const Duration(days: 1));
    }
  }

  Future<void> cancelAll() async {
    try {
      await flutterLocalNotificationsPlugin.cancelAll();
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kScheduledUntilKey);
    } catch (e, st) {
      debugPrint('[cancelAll] error -> $e\n$st');
    }
  }

  // ---------------- small helpers ----------------
  DateTime _parseTime(DateTime day, String timeText) {
    final parts = timeText.trim().split(' ');
    final hm = parts[0].split(':');
    int hour = int.tryParse(hm[0]) ?? 0;
    int minute = int.tryParse(hm[1]) ?? 0;
    final period = parts.length > 1 ? parts[1] : '';

    if (hour >= 13) {
      // 24-hour provided
    } else {
      if (period.contains('مساء')) {
        if (hour < 12) hour += 12;
      } else if (period.contains('صباح')) {
        if (hour == 12) hour = 0;
      }
    }

    return DateTime(day.year, day.month, day.day, hour, minute);
  }

  Duration _getReminderDurationFromString(String reminder) {
    switch (reminder) {
      case 'ساعة': return const Duration(hours: 1);
      case 'ساعة ونصف': return const Duration(minutes: 90);
      case 'ساعتين': return const Duration(hours: 2);
      default: return const Duration(minutes: 30);
    }
  }

  Duration _getShiftDurationFromSystem(String system) {
    if (system == 'نظام العمل 12/24-12/48') return const Duration(hours: 12);
    if (system == 'نظام العمل يوم عمل - يومين راحة') return const Duration(hours: 24);
    if (system == 'يومين عمل ٤ أيام راحة') return const Duration(hours: 48);
    return const Duration(hours: 8);
  }

  Map<DateTime, String> _generateWorkScheduleSegment(String system, DateTime startDate, int maintenanceInterval, {int days = 365}) {
    final schedule = <DateTime, String>{};
    int shiftCounter = 0;
    String lastShift = "راحة";
    bool isFirstShift = true;
    for (int i = 0; i < days; i++) {
      final dayLocal = startDate.add(Duration(days: i));
      String shift = "راحة";

      if (system == 'نظام العمل 12/24-12/48') {
        final cycle = i % 4;
        if (cycle == 0) shift = "صبح";
        if (cycle == 1) shift = "ليل";
      } else if (system == 'نظام العمل يوم عمل - يومين راحة') {
        shift = (i % 3 == 0) ? "صبح" : "راحة";
      } else if (system == 'يومين عمل ٤ أيام راحة') {
        final cycle = i % 6;
        if (cycle == 0 || cycle == 1) shift = "صبح";
      } else if (system == '3 أيام عمل (صبح - عصر - ليل) يليها يومين راحة') {
        final cycle = i % 5;
        if (cycle == 0) shift = "صبح";
        if (cycle == 1) shift = "عصر";
        if (cycle == 2) shift = "ليل";
      } else if (system == '6 أيام عمل 2 يوم راحة') {
        final cycle = i % 8;
        if (cycle == 0 || cycle == 1) shift = "صبح";
        if (cycle == 2 || cycle == 3) shift = "عصر";
        if (cycle == 4 || cycle == 5) shift = "ليل";
      } else if (system == 'صباحي') {
        final weekday = dayLocal.weekday;
        shift = (weekday >= 1 && weekday <= 5) ? "صبح" : "راحة";
      }

      if (shift != "راحة" && lastShift == "راحة") {
        shiftCounter++;
        if (isFirstShift && maintenanceInterval > 0) {
          shift = "صيانة";
          isFirstShift = false;
        } else {
          if (maintenanceInterval > 0 && shiftCounter > 1 && (shiftCounter - 1) % maintenanceInterval == 0) {
            shift = "صيانة";
          }
        }
      } else if (shift != "راحة" && lastShift != "راحة") {
        if (lastShift == "صيانة") shift = "صيانة";
      }

      final keyUtc = DateTime.utc(dayLocal.year, dayLocal.month, dayLocal.day);
      schedule[keyUtc] = shift;
      lastShift = shift;
    }
    return schedule;
  }

  void _handleNotificationResponse(NotificationResponse response) {
    final payload = response.payload;
    debugPrint('[handleNotificationResponse] payload=$payload');
    if (payload == null) return;

    // ✅ معالجة إشعار تذكير الاشتراك
    if (payload == 'purchase_reminder') {
      // إذا الاشتراك غير مفعل — ابدأ عملية الشراء
      if (!PurchaseManager.instance.isActive()) {
        try {
          PurchaseManager.instance.buyYearly();
        } catch (e) {
          debugPrint('[handleNotificationResponse] buyYearly failed -> $e');
        }
      } else {
        // لو مفعل — عرض رسالة صغيرة بحالة الاشتراك
        final rem = PurchaseManager.instance.remainingDuration();
        final daysLeft = rem == null ? null : (rem.inDays + 1);
        final body = daysLeft != null
            ? 'اشتراكك مفعل — تبقى $daysLeft يومًا.'
            : 'اشتراكك مفعل.';
        showImmediateNotification(
          id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
          title: 'حالة الاشتراك',
          body: body,
        );
      }
      return; // ⛔ لا تكمل باقي المعالجة
    }

    try {
      final parts = payload.split('|');
      if (parts.length >= 3) {
        final dayIso = parts[0];
        final offset = parts[1];
        final shift = parts.sublist(2).join('|');
        debugPrint(
            '[handleNotificationResponse] parsed -> day=$dayIso offset=$offset shift=$shift');

        // 🕘 عندما يضغط المستخدم على إشعار الـ "check-in"
        if (offset == '2') {
          try {
            final day = DateTime.parse(dayIso);
            debugPrint(
                '[handleNotificationResponse] checkin tap -> ensuring remaining notifications for $day shift=$shift');
            _ensureRemainingNotificationsForDay(day, shift).catchError((e, st) {
              debugPrint(
                  '[handleNotificationResponse] _ensureRemainingNotificationsForDay error -> $e\n$st');
            });
          } catch (e, st) {
            debugPrint(
                '[handleNotificationResponse] parse dayIso failed -> $e\n$st');
          }
        }
      }
    } catch (e, st) {
      debugPrint('[handleNotificationResponse] parse error -> $e\n$st');
    }
  }

  Future<void> sendFirstRunConfirmationIfNeeded() async {
    final prefs = await SharedPreferences.getInstance();
    final alreadySent = prefs.getBool(_kConfirmationShownKey) ?? false;
    if (alreadySent) return;
    await showImmediateNotification(id: 999999, title: 'Notifications enabled ✅', body: 'You will receive reminders from this app. (one-time)', payload: 'confirmation|notifications_enabled');
    await prefs.setBool(_kConfirmationShownKey, true);
  }

  Future<void> sendWelcomeNotificationOnce() async {
    final prefs = await SharedPreferences.getInstance();
    final alreadyShown = prefs.getBool(_kWelcomeShownKey) ?? false;
    if (alreadyShown) return;
    await Future.delayed(const Duration(seconds: 6));
    await showImmediateNotification(id: 1000000, title: 'مرحبا بك في التطبيق!', body: 'شكراً لتثبيت التطبيق — سنذكرك بمواعيد دوامك.', payload: 'welcome|first_run');
    await prefs.setBool(_kWelcomeShownKey, true);
  }

  Future<void> onAppResumed() async {
    try {
      final tzName = (await FlutterTimezone.getLocalTimezone()).toString();
      if (_lastKnownTimeZone == null || _lastKnownTimeZone != tzName) await _initTimezone();
    } catch (_) {
      await _initTimezone();
    }
    await scheduleNextNDays(60);
  }

  Future<void> rescheduleIfNeeded({bool force = false}) async {
    if (force) {
      await rescheduleAllNotifications(days: 30, forceClear: true);
    } else {
      await onAppResumed();
    }
  }

  // Compatibility static method used earlier in your code
  static Future<void> rescheduleAllNotifications({int days = 7, bool forceClear = false}) async {
    debugPrint('[NotificationsService] rescheduleAllNotifications days=$days forceClear=$forceClear');
    try {
      if (forceClear) {
        debugPrint('[NotificationsService] forceClear=true -> calling cancelAll()');
        await NotificationsService.instance.cancelAll();
        debugPrint('[NotificationsService] cancelAll() done');
      }
      await NotificationsService.instance.init();
      await NotificationsService.instance.scheduleNextNDays(days);
      debugPrint('[NotificationsService] scheduleNextNDays returned');
    } catch (e, st) {
      debugPrint('[NotificationsService] reschedule error -> $e\n$st');
    }
  }

  Future<void> rescheduleFromBoot() async {
    await init();
    await scheduleNextNDays(30);
  }

  Future<void> debugListPending() async {
    try {
      final pending = await flutterLocalNotificationsPlugin.pendingNotificationRequests();
      debugPrint('[debugListPending] pending.count=${pending.length}');
      for (final p in pending) debugPrint('[PENDING] -> id=${p.id} title=${p.title} body=${p.body} payload=${p.payload}');
    } catch (e) {
      debugPrint('[debugListPending] error -> $e');
    }
  }

  Future<void> scheduleFromSettings({
    required String workSystem,
    required DateTime startDate,
    required int maintenanceInterval,
    required String morningStart,
    required String morningCheckIn,
    required String afternoonStart,
    required String afternoonCheckIn,
    required String nightStart,
    required String nightCheckIn,
    required String reminder,
    int days = 60,
  }) async {
    await init();
    await requestPermissions();
    await requestExactAlarmPermissionIfNeeded();
    await requestIgnoreBatteryOptimizationsIfNeeded();

    final scheduleMap = _generateWorkScheduleSegment(workSystem, startDate, maintenanceInterval, days: days + 365);

    DateTime current = DateTime.now();
    current = DateTime(current.year, current.month, current.day);
    int scheduled = 0;
    int lookAhead = 0;
    final int safetyLimit = days + 365;

    while (scheduled < days && lookAhead < safetyLimit) {
      final day = current.add(Duration(days: lookAhead));
      final keyUtc = DateTime.utc(day.year, day.month, day.day);
      final shift = scheduleMap[keyUtc];

      if (shift != null && shift != 'راحة') {
        try {
          await cancelNotificationsForDay(day);
          await _scheduleNotificationsForDayWithConfig(localDay: day, startDate: startDate, workSystem: workSystem, morningStart: morningStart, morningCheckIn: morningCheckIn, afternoonStart: afternoonStart, afternoonCheckIn: afternoonCheckIn, nightStart: nightStart, nightCheckIn: nightCheckIn, reminder: reminder, maintenanceInterval: maintenanceInterval);
          scheduled++;
        } catch (e, st) {
          debugPrint('[scheduleFromSettings] error scheduling $day -> $e\n$st');
        }
      }

      lookAhead++;
    }
  }

  Future<void> _scheduleNotificationsForDayWithConfig({
    required DateTime localDay,
    required DateTime startDate,
    required String workSystem,
    required String morningStart,
    required String morningCheckIn,
    required String afternoonStart,
    required String afternoonCheckIn,
    required String nightStart,
    required String nightCheckIn,
    required String reminder,
    required int maintenanceInterval,
  }) async {
    final day = DateTime(localDay.year, localDay.month, localDay.day);
    final reminderDuration = _getReminderDurationFromString(reminder);
    final schedule = _generateWorkScheduleSegment(workSystem, startDate, maintenanceInterval, days: 400);

    final keyUtc = DateTime.utc(day.year, day.month, day.day);
    final shift = schedule[keyUtc] ?? 'راحة';
    if (shift == 'راحة') return;

    DateTime startDT;
    DateTime checkInDT;
    if (shift == 'صبح' || shift == 'صيانة') {
      startDT = _parseTime(day, morningStart);
      checkInDT = _parseTime(day, morningCheckIn);
    } else if (shift == 'عصر') {
      startDT = _parseTime(day, afternoonStart);
      checkInDT = _parseTime(day, afternoonCheckIn);
    } else {
      startDT = _parseTime(day, nightStart);
      checkInDT = _parseTime(day, nightCheckIn);
    }

    final shiftDuration = _getShiftDurationFromSystem(workSystem);
    final endDT = startDT.add(shiftDuration);

    final Map<int, DateTime> times = {
      0: startDT.subtract(const Duration(hours: 12)),
      1: startDT.subtract(reminderDuration),
      2: checkInDT,
      3: endDT,
    };

    final dayUtc = DateTime.utc(day.year, day.month, day.day);

    for (final entry in times.entries) {
      final offset = entry.key;
      final scheduledLocal = entry.value;
      final id = _notificationIdFor(dayUtc, offset);
      try {
        final tzDt = tz.TZDateTime.from(scheduledLocal, tz.local);
        if (tzDt.isBefore(tz.TZDateTime.now(tz.local))) continue;
        final payload = '${dayUtc.toIso8601String()}|$offset|$shift';
        await scheduleNotification(id: id, title: _titleForOffset(offset, shift), body: _bodyForOffset(offset, shift), scheduledDateTimeLocal: scheduledLocal, payload: payload, channelId: 'work_channel');
      } catch (e, st) {
        debugPrint('[scheduleWithConfig] error scheduling offset=$offset -> $e\n$st');
      }
    }
  }

  Future<void> scheduleConfirmationAfterSeconds(int seconds, String message) async {
    final now = DateTime.now();
    final scheduledTime = now.add(Duration(seconds: seconds));
    final id = now.millisecondsSinceEpoch.remainder(100000) + 200000;
    await scheduleNotification(id: id, title: 'تأكيد الإعداد', body: message, scheduledDateTimeLocal: scheduledTime, payload: 'confirmation|$id', channelId: 'first_run_channel');
  }
  Future<void> scheduleDailySubscriptionReminderAt9() async {
    try {
      await init();
      final prefs = await SharedPreferences.getInstance();

      // لا تعيد الجدولة لو المستخدم لغى التذكير صراحة (بعد الاشتراك أو اختيار الغاء)
      final cancelled = prefs.getBool(_kSubscriptionReminderCancelled) ?? false;
      if (cancelled) return;

      // لو الاشتراك مفعل — الغي التذكير
      if (PurchaseManager.instance.isActive()) {
        await cancelDailySubscriptionReminder(markCancelled: true);
        return;
      }

      // نص الإشعار — يظهر عدد الأيام المتبقية إن وجد
      final daysLeft = PurchaseManager.instance.remainingDuration()?.inDays;
      String body;
      if (daysLeft != null && daysLeft > 0) {
        body = 'اشتراك بريميوم — تبقى $daysLeft يومًا. فعّل الاشتراك للاستمرار.';
      } else {
        body = 'جرب 7 أيام مجانًا ثم اشترك سنويًا \$19.99 — فعّل النسخة البريميوم الآن.';
      }

      // استخدم الدالة الموجودة scheduleDailyAtTime (أنت عندك دالة scheduleDailyAtTime)
      await scheduleDailyAtTime(
        id: _kSubscriptionReminderId,
        title: 'اشترك في النسخة البريميوم',
        body: body,
        hour: 9,
        minute: 0,
        channelId: 'purchase_channel',
      );

      await prefs.setBool(_kSubscriptionReminderScheduled, true);
      debugPrint('[Notifications] scheduled purchase reminder at 09:00');
    } catch (e, st) {
      debugPrint('[Notifications] scheduleDailySubscriptionReminderAt9 error -> $e\n$st');
    }
  }
  Future<void> cancelDailySubscriptionReminder({bool markCancelled = true}) async {
    try {
      await flutterLocalNotificationsPlugin.cancel(_kSubscriptionReminderId);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_kSubscriptionReminderScheduled, false);
      if (markCancelled) await prefs.setBool(_kSubscriptionReminderCancelled, true);
      debugPrint('[Notifications] canceled purchase reminder id=$_kSubscriptionReminderId');
    } catch (e, st) {
      debugPrint('[Notifications] cancelDailySubscriptionReminder error -> $e\n$st');
    }
  }

  Future<void> ensureSubscriptionReminderState() async {
    try {
      if (PurchaseManager.instance.isActive()) {
        await cancelDailySubscriptionReminder(markCancelled: true);
      } else {
        await scheduleDailySubscriptionReminderAt9();
      }
    } catch (e, st) {
      debugPrint('[Notifications] ensureSubscriptionReminderState error -> $e\n$st');
    }
  }

  Future<void> scheduleSaveSuccessNotification({int seconds = 60}) async {
    final now = DateTime.now();
    final id = now.millisecondsSinceEpoch.remainder(100000) + 300000;
    if (seconds <= 0) {
      await showImmediateNotification(id: id, title: 'تم حفظ الإعدادات ✅', body: 'تم حفظ الإعدادات بنجاح. سيتم إرسال التذكيرات في مواعيدها.', payload: 'save_success|$id');
    } else {
      final scheduledTime = now.add(Duration(seconds: seconds));
      await scheduleNotification(id: id, title: 'تم حفظ الإعدادات ✅', body: 'تم حفظ الإعدادات بنجاح. سيتم إرسال التذكيرات في مواعيدها.', scheduledDateTimeLocal: scheduledTime, payload: 'save_success|$id', channelId: 'first_run_channel');
    }
  }
  /// Convenience wrapper to show a simple immediate notification.
  /// Used by PurchaseManager.checkTrialAndNotifyIfExpired() to notify user.
  Future<void> showSimpleNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  })
  async {
    try {
      await init();

      final details = NotificationDetails(
        android: AndroidNotificationDetails(
          'purchase_channel', // نفس القناة التي أنشأناها في init()
          'Purchase Reminders',
          channelDescription: 'Subscription / purchase reminders',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          showProgress: false,
        ),
        iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true),
      );

      await flutterLocalNotificationsPlugin.show(id, title, body, details, payload: payload);
      debugPrint('[showSimpleNotification] shown id=$id title=$title');
    } catch (e, st) {
      debugPrint('[showSimpleNotification] error -> $e\n$st');
    }
  }

}
