// lib/service/purchase_manager.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:connectivity_plus/connectivity_plus.dart';

import 'notifications_service.dart';

const String kYearlySku = 'work_reminder_yearly';

const String _kPrefsKeySubscription = 'pm_subscription_state';
const String _kPrefsKeyPendingReceipts = 'pm_pending_receipts';

// Trial-related keys
const String _kPrefsKeyTrialStart = 'pm_trial_start';
const String _kPrefsShowUpgradeOnLaunch = 'pm_show_upgrade_on_launch';
const int _kTrialDays = 7;

class SubscriptionState {
  final bool active;
  final DateTime? expiresAt;
  final bool isInTrial;
  final String? platform; // 'android' | 'ios'
  final String? rawPayload;

  SubscriptionState({
    required this.active,
    this.expiresAt,
    this.isInTrial = false,
    this.platform,
    this.rawPayload,
  });

  Map<String, dynamic> toJson() => {
    'active': active,
    'expiresAt': expiresAt?.toIso8601String(),
    'isInTrial': isInTrial,
    'platform': platform,
    'rawPayload': rawPayload,
  };

  static SubscriptionState fromJson(Map<String, dynamic> j) => SubscriptionState(
    active: j['active'] == true,
    expiresAt: j['expiresAt'] != null ? DateTime.parse(j['expiresAt']) : null,
    isInTrial: j['isInTrial'] == true,
    platform: j['platform'],
    rawPayload: j['rawPayload'],
  );
}

class PendingReceipt {
  final String platform; // 'android' or 'ios'
  final String productId;
  final String receipt; // purchaseToken for android, base64 receipt for ios

  PendingReceipt({required this.platform, required this.productId, required this.receipt});

  Map<String, dynamic> toJson() => {
    'platform': platform,
    'productId': productId,
    'receipt': receipt,
  };

  static PendingReceipt fromJson(Map<String, dynamic> j) => PendingReceipt(
    platform: j['platform'],
    productId: j['productId'],
    receipt: j['receipt'],
  );
}

class PurchaseManager {
  PurchaseManager._internal();
  static final PurchaseManager instance = PurchaseManager._internal();

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;
  List<ProductDetails> products = [];
  bool _initialized = false;

  SubscriptionState? _cachedState;
  SharedPreferences? _prefs;

  // backend URL (ضع رابط سيرفرك هنا) — هذا endpoint يجب أن يتحقق من receipt ويعيد { ok, expiresAt, isInTrial }
  String backendVerifyEndpoint = 'https://your-server.example/api/verify-purchase';

  // optional: identifier to send to server so it can map device <-> user if needed
  String? deviceIdentifier;

  /// Initialize PurchaseManager — call early in app startup
  /// الآن: يقوم أيضاً بضبط تاريخ بداية الفترة التجريبية إن لم يكن موجوداً
  Future<void> init({required String deviceId}) async {
    if (_initialized) return;
    _initialized = true;
    deviceIdentifier = deviceId;

    _prefs = await SharedPreferences.getInstance();
    _loadLocalState();

    final available = await _iap.isAvailable();
    if (!available) {
      debugPrint('[PurchaseManager] store not available');
      // still keep local state and pending receipts
    } else {
      await _queryProducts();
      _sub = _iap.purchaseStream.listen(
        _onPurchaseUpdated,
        onDone: () => _sub?.cancel(),
        onError: (e) {
          debugPrint('[PurchaseManager] purchaseStream error: $e');
        },
      );
    }

    // 🟢 ensure subscription reminder is scheduled/cancelled once we know local state
    try {
      await NotificationsService.instance.ensureSubscriptionReminderState();
    } catch (e) {
      debugPrint('[PurchaseManager] ensureSubscriptionReminderState failed -> $e');
    }

    // 🔁 try to send pending receipts when connectivity changes
    Connectivity().onConnectivityChanged.listen((_) async => await sendPendingReceipts());

    // 🚀 attempt to flush pending receipts now
    await sendPendingReceipts();

    // === Trial handling: set trial start if first run and perform an initial check ===
    try {
      await ensureTrialStartIfNeeded();
      await checkTrialAndNotifyIfExpired();
    } catch (e) {
      debugPrint('[PurchaseManager] trial init/check failed -> $e');
    }
  }

  Future<void> _queryProducts() async {
    try {
      final response = await _iap.queryProductDetails({kYearlySku});
      products = response.productDetails;
      debugPrint('[PurchaseManager] found products: ${products.map((p) => p.id).toList()}');
    } catch (e) {
      debugPrint('[PurchaseManager] queryProductDetails failed: $e');
    }
  }

  /// Trigger purchase flow for yearly subscription
  Future<void> buyYearly() async {
    final pd = products.firstWhere((p) => p.id == kYearlySku, orElse: () => throw Exception('Product not found'));
    final purchaseParam = PurchaseParam(productDetails: pd);
    try {
      // for subscriptions the same API is used; the store handles trial/price
      await _iap.buyNonConsumable(purchaseParam: purchaseParam);
    } catch (e) {
      debugPrint('[PurchaseManager] buy failed: $e');
    }
  }

  Future<void> restorePurchases() async {
    try {
      await _iap.restorePurchases();
    } catch (e) {
      debugPrint('[PurchaseManager] restorePurchases failed: $e');
    }
  }

  Future<void> _onPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) async {
    for (final pd in purchaseDetailsList) {
      debugPrint('[PurchaseManager] purchase update: ${pd.productID} status=${pd.status}');

      if (pd.status == PurchaseStatus.pending) {
        // TODO: show pending UI if needed
      } else if (pd.status == PurchaseStatus.error) {
        // handle error
        debugPrint('[PurchaseManager] purchase error: ${pd.error}');
      } else if (pd.status == PurchaseStatus.purchased || pd.status == PurchaseStatus.restored) {
        final platform = _detectPlatform(pd);
        final receipt = pd.verificationData.serverVerificationData; // purchaseToken on Android, receipt on iOS

        // queue the receipt for server verification (offline-friendly)
        await _enqueueReceipt(platform: platform, productId: pd.productID, receipt: receipt);

        // attempt immediate verification (positional args)
        final success = await _sendReceiptToBackend(platform, pd.productID, receipt);
        if (success) {
          // mark purchase as acknowledged locally
          if (Platform.isAndroid) {
            try {
              await InAppPurchase.instance.completePurchase(pd);
            } catch (e) {
              debugPrint('[PurchaseManager] completePurchase failed: $e');
            }
          }
          // clear upgrade-on-launch flag if any
          try {
            await markShowUpgradeOnLaunch(false);
          } catch (_) {}
        }
      }
    }
  }

  String _detectPlatform(PurchaseDetails pd) {
    final src = pd.verificationData.source ?? '';
    if (src.toLowerCase().contains('play')) return 'android';
    if (src.toLowerCase().contains('appstore') || src.toLowerCase().contains('ios')) return 'ios';
    return Platform.isAndroid ? 'android' : 'ios';
  }

  Future<void> _enqueueReceipt({required String platform, required String productId, required String receipt}) async {
    final listJson = _prefs?.getStringList(_kPrefsKeyPendingReceipts) ?? <String>[];
    final pending = PendingReceipt(platform: platform, productId: productId, receipt: receipt);
    listJson.add(jsonEncode(pending.toJson()));
    await _prefs?.setStringList(_kPrefsKeyPendingReceipts, listJson);
    debugPrint('[PurchaseManager] enqueued receipt for $platform/$productId');
  }

  Future<void> sendPendingReceipts() async {
    final listJson = _prefs?.getStringList(_kPrefsKeyPendingReceipts) ?? <String>[];
    if (listJson.isEmpty) return;

    // simple retry FIFO
    final remaining = <String>[];
    for (final item in listJson) {
      try {
        final decoded = jsonDecode(item) as Map<String, dynamic>;
        final pr = PendingReceipt.fromJson(decoded);
        final ok = await _sendReceiptToBackend(pr.platform, pr.productId, pr.receipt);
        if (!ok) remaining.add(item);
      } catch (e) {
        debugPrint('[PurchaseManager] sendPendingReceipts decode/send error: $e');
        remaining.add(item);
      }
    }

    await _prefs?.setStringList(_kPrefsKeyPendingReceipts, remaining);
    debugPrint('[PurchaseManager] pending receipts flushed, remaining=${remaining.length}');
  }

  /// send receipt to your backend for verification with Google/Apple
  Future<bool> _sendReceiptToBackend(String platform, String productId, String receipt) async {
    if (backendVerifyEndpoint.isEmpty) {
      debugPrint('[PurchaseManager] backendVerifyEndpoint not set — skipping verification (debug)');
      return false;
    }

    try {
      // POST to your server — server must validate with Google/Apple and return { ok:bool, expiresAt: ISO8601, isInTrial:bool }
      final body = {
        'platform': platform,
        'productId': productId,
        'receipt': receipt,
        'deviceId': deviceIdentifier,
      };

      final r = await http
          .post(
        Uri.parse(backendVerifyEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      )
          .timeout(const Duration(seconds: 10));

      if (r.statusCode == 200) {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        if (j['ok'] == true) {
          DateTime? expires;
          if (j['expiresAt'] != null) {
            expires = DateTime.parse(j['expiresAt']);
          }

          _cachedState = SubscriptionState(
            active: true,
            expiresAt: expires,
            isInTrial: j['isInTrial'] == true,
            platform: platform,
            rawPayload: j['rawPayload'] != null ? jsonEncode(j['rawPayload']) : receipt,
          );

          await _saveLocalState();

          // 🟢 cancel subscription reminders if purchase verified
          try {
            await NotificationsService.instance.cancelDailySubscriptionReminder(markCancelled: true);
          } catch (e) {
            debugPrint('[PurchaseManager] cancelDailySubscriptionReminder failed -> $e');
          }

          // clear upgrade-on-launch if set
          try {
            await markShowUpgradeOnLaunch(false);
          } catch (_) {}

          return true;
        }
      }
      return false;
    } catch (e) {
      debugPrint('[PurchaseManager] _sendReceiptToBackend error: $e');
      return false; // will be retried later
    }
  }

  void _loadLocalState() {
    final raw = _prefs?.getString(_kPrefsKeySubscription);
    if (raw != null) {
      try {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        _cachedState = SubscriptionState.fromJson(j);
      } catch (e) {
        debugPrint('[PurchaseManager] loadLocalState decode error -> $e');
        _cachedState = null;
      }
    }
  }

  Future<void> _saveLocalState() async {
    if (_cachedState == null) {
      await _prefs?.remove(_kPrefsKeySubscription);
      return;
    }
    await _prefs?.setString(_kPrefsKeySubscription, jsonEncode(_cachedState!.toJson()));
  }

  bool isActive() {
    if (_cachedState == null) return false;
    if (!_cachedState!.active) return false;
    if (_cachedState!.expiresAt != null) {
      return DateTime.now().isBefore(_cachedState!.expiresAt!);
    }
    return true; // active but no expiry info
  }

  Duration? remainingDuration() {
    final exp = _cachedState?.expiresAt;
    if (exp == null) return null;
    return exp.difference(DateTime.now());
  }

  DateTime? expiresAt() => _cachedState?.expiresAt;

  // optional: manual check with backend to refresh state
  Future<void> refreshFromBackend() async {
    // if we have a cached rawPayload we can re-send it
    final raw = _cachedState?.rawPayload;
    if (raw == null) return;
    // attempt to re-verify with same fields — implementation depends on your backend
    await sendPendingReceipts();
  }

  // debug: clear local state (for QA)
  Future<void> clearLocalState() async {
    _cachedState = null;
    await _prefs?.remove(_kPrefsKeySubscription);
    await _prefs?.remove(_kPrefsKeyPendingReceipts);
  }

  void dispose() {
    _sub?.cancel();
  }

  // ---------------------------
  // Trial-related helpers
  // ---------------------------

  /// Set trial start time if it's not present yet.
  Future<void> ensureTrialStartIfNeeded() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    if (!prefs.containsKey(_kPrefsKeyTrialStart)) {
      await prefs.setString(_kPrefsKeyTrialStart, DateTime.now().toIso8601String());
      debugPrint('[PurchaseManager] trialStart set -> ${DateTime.now()}');
    }
  }

  /// Returns true if the trial period (7 days) has expired AND there is no active subscription.
  bool isTrialExpired() {
    final prefs = _prefs;
    if (prefs == null) return false;
    final raw = prefs.getString(_kPrefsKeyTrialStart);
    if (raw == null) return false;
    try {
      final start = DateTime.parse(raw);
      final expire = start.add(Duration(days: _kTrialDays));
      // expired if now after expire AND no active subscription
      return DateTime.now().isAfter(expire) && !isActive();
    } catch (e) {
      debugPrint('[PurchaseManager] isTrialExpired parse error -> $e');
      return false;
    }
  }

  /// Mark whether to show the upgrade screen on next app launch
  Future<void> markShowUpgradeOnLaunch(bool show) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _prefs = prefs;
    await prefs.setBool(_kPrefsShowUpgradeOnLaunch, show);
  }

  /// Check the stored flag (used by UI on resume/start)
  bool shouldShowUpgradeOnLaunch() {
    return _prefs?.getBool(_kPrefsShowUpgradeOnLaunch) ?? false;
  }

  Future<void> checkTrialAndNotifyIfExpired() async {
    try {
      final prefs = _prefs ?? await SharedPreferences.getInstance();
      _prefs = prefs;

      final expired = isTrialExpired();

      await prefs.setBool(_kPrefsShowUpgradeOnLaunch, expired);

      if (expired) {
        debugPrint('[PurchaseManager] Trial expired -> flag set to show upgrade on launch');
      } else {
        debugPrint('[PurchaseManager] Trial active -> ensure upgrade flag cleared');
      }
    } catch (e, st) {
      debugPrint('[PurchaseManager] checkTrialAndNotifyIfExpired error -> $e\n$st');
    }
  }
}
