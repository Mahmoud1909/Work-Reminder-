// lib/main.dart
import 'dart:async';
import 'dart:io' show Platform;

import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter/foundation.dart' show debugPrint, kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tz; // initializeTimeZones()
import 'package:workmanager/workmanager.dart';

// Optional fallback intents
import 'package:package_info_plus/package_info_plus.dart';

import 'screens/settings_page.dart' show SettingsPage;
import 'screens/calendar_page.dart';
import 'screens/upgrade_prompt_page.dart';
import 'service/notifications_service.dart';
import 'service/background_service.dart' show backgroundTaskWrapper;
import 'service/purchase Manager.dart';
late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

// same native channel used elsewhere in your project
const MethodChannel _nativeChannel = MethodChannel(
  'khamsat/native_notifications',
);

const String WM_TASK_RESCHEDULE = 'khamsat_reschedule_task';
const String WM_TASK_SHOW_TEST = 'khamsat_show_test_notification';

// SharedPreferences key used to mark "show upgrade page on next app open"
const String _kPrefsShowUpgradeOnLaunch = 'pm_show_upgrade_on_launch';

// navigator key used across the app (so we can push UpgradePromptPage from outside widget tree)
final GlobalKey<NavigatorState> gNavigatorKey = GlobalKey<NavigatorState>();

// Prevent showing upgrade prompt multiple times in same session
bool _upgradePromptShownThisSession = false;

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    debugPrint('[WM][callback] invoked task=$taskName inputData=$inputData');
    try {
      final ok = await backgroundTaskWrapper(
        taskName ?? '',
        inputData as Map<String, dynamic>?,
      );
      debugPrint('[WM][callback] backgroundTaskWrapper returned $ok');
      return ok;
    } catch (e, st) {
      debugPrint('[WM][callback] error -> $e\n$st');
      return Future.value(false);
    }
  });
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // load tz DB early
  tz.initializeTimeZones();
  debugPrint('[main] tz DB initialized');

  debugPrint('[main] start');

  try {
    await NotificationsService.initialize();
    debugPrint('[main] NotificationsService init done');
  } catch (e, st) {
    debugPrint('[main] NotificationsService init error -> $e\n$st');
  }

  // give PurchaseManager a device id (use package name as simple id)
  try {
    final pkg = await PackageInfo.fromPlatform();
    await PurchaseManager.instance.init(deviceId: pkg.packageName);
    debugPrint(
      '[main] PurchaseManager initialized with deviceId=${pkg.packageName}',
    );

    await NotificationsService.instance.ensureSubscriptionReminderState();
  } catch (e, st) {
    debugPrint('[main] PurchaseManager init error -> $e\n$st');
  }

  flutterLocalNotificationsPlugin =
      NotificationsService.instance.flutterLocalNotificationsPlugin;

  // set navigator key in notifications service (used for opening UI from notification handlers)
  NotificationsService.instance.setNavigatorKey(gNavigatorKey);

  try {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
    await Workmanager().registerPeriodicTask(
      "khamsat_periodic_rescheduler",
      WM_TASK_RESCHEDULE,
      frequency: const Duration(minutes: 15),
      initialDelay: const Duration(seconds: 15),
      existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
      constraints: Constraints(
        networkType: NetworkType.notRequired,
        requiresBatteryNotLow: false,
        requiresCharging: false,
        requiresDeviceIdle: false,
        requiresStorageNotLow: false,
      ),
    );

    debugPrint('[main] Workmanager registered');
  } catch (e, st) {
    debugPrint('[main] Workmanager init error -> $e\n$st');
  }

  runApp(MyApp(navigatorKey: gNavigatorKey));

  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try {
      final ok = await _ensureAllRequiredPermissions(gNavigatorKey);
      debugPrint('[main.postFrame] required permissions ok -> $ok');

      // check trial and possibly show upgrade page on launch
      await _maybeShowUpgradeIfNeeded();

      try {
        final prefs = await SharedPreferences.getInstance();
        final hasSettings =
            prefs.containsKey('workSystem') && prefs.containsKey('startDate');
        if (hasSettings) {
          debugPrint(
            '[main.postFrame] settings found -> rescheduling notifications',
          );
          await NotificationsService.instance.rescheduleIfNeeded(force: false);
        } else {
          debugPrint(
            '[main.postFrame] no saved settings -> user must configure app',
          );
        }
      } catch (e, st) {
        debugPrint('[main.postFrame] reschedule on startup error -> $e\n$st');
      }
    } catch (e, st) {
      debugPrint('[main.postFrame] top-level error -> $e\n$st');
    }
  });
}

Future<bool> _ensureAllRequiredPermissions(
    GlobalKey<NavigatorState> navigatorKey,
    ) async {
  if (kIsWeb) return true;

  final prefs = await SharedPreferences.getInstance();
  final blockingMode = prefs.getBool('required_perms_blocking') ?? true;

  if (Platform.isIOS) {
    try {
      final result = await Permission.notification.request();
      debugPrint('[ensurePerms] iOS notification.request -> $result');
      final granted = result.isGranted;

      await prefs.setBool('last_required_perms_notifications', granted);
      await prefs.setBool('last_required_perms_exactalarm', true);

      if (!granted && blockingMode) {
        final ctx = navigatorKey.currentState?.overlay?.context;
        if (ctx != null) {
          await showDialog(
            context: ctx,
            builder: (c) => AlertDialog(
              title: const Text('السماح بالإشعارات'),
              content: const Text(
                'يحتاج التطبيق إذن الإشعارات ليعمل بشكل صحيح.\nيرجى السماح من إعدادات النظام.',
              ),
              actions: [
                TextButton(
                  onPressed: () async {
                    await openAppSettings();
                    Navigator.pop(c);
                  },
                  child: const Text('فتح الإعدادات'),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(c),
                  child: const Text('حسنًا'),
                ),
              ],
            ),
          );
        }
      }

      return granted;
    } catch (e) {
      debugPrint('[ensurePerms] iOS permission request failed -> $e');
      return true;
    }
  }

  bool notificationsOk = false;
  bool exactAlarmOk = false;

  final ctx = navigatorKey.currentState?.overlay?.context;

  Future<void> _handleNotificationPermission() async {
    final status = await Permission.notification.status;
    debugPrint('[ensurePerms] notification.status = $status');

    if (status.isGranted) {
      notificationsOk = true;
      return;
    }

    bool done = false;
    while (!done) {
      final requestResult = await Permission.notification.request();
      debugPrint('[ensurePerms] notification.request -> $requestResult');

      if (requestResult.isGranted) {
        notificationsOk = true;
        done = true;
        break;
      }

      if (ctx == null) {
        notificationsOk = false;
        done = true;
        break;
      }

      final choice = await showDialog<String>(
        context: ctx,
        barrierDismissible: !blockingMode,
        builder: (c) {
          return AlertDialog(
            title: const Text('السماح بالإشعارات'),
            content: const Text(
              'يحتاج التطبيق إذن الإشعارات لعرض التنبيهات في مواعيدها. '
                  'يرجى السماح عند المطالبة أو فتح إعدادات التطبيق لتشغيل الإشعارات.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(c).pop('request'),
                child: const Text('اطلب الآن'),
              ),
              TextButton(
                onPressed: () => Navigator.of(c).pop('settings'),
                child: const Text('افتح إعدادات التطبيق'),
              ),
              if (!blockingMode)
                TextButton(
                  onPressed: () => Navigator.of(c).pop('skip'),
                  child: const Text('تجاهل مؤقتاً'),
                ),
            ],
          );
        },
      );

      if (choice == 'request') {
        continue;
      } else if (choice == 'settings') {
        await openAppSettings();
        continue;
      } else {
        notificationsOk = false;
        done = true;
      }
    }
  }

  Future<void> _handleExactAlarmPermission() async {
    try {
      final canSchedule = await _nativeChannel.invokeMethod<bool>(
        'canScheduleExactAlarms',
      );
      if (canSchedule == true) {
        exactAlarmOk = true;
        debugPrint('[ensurePerms] native canScheduleExactAlarms -> true');
        return;
      }
    } catch (e) {
      debugPrint(
        '[ensurePerms] native canScheduleExactAlarms not implemented -> $e',
      );
    }

    try {
      await _nativeChannel.invokeMethod('requestScheduleExactAlarm');
      exactAlarmOk = true;
    } catch (e) {
      debugPrint(
        '[ensurePerms] requestScheduleExactAlarm native failed (silent) -> $e',
      );
      exactAlarmOk = false;
    }
  }

  await _handleNotificationPermission();

  if (!notificationsOk && blockingMode) {
    debugPrint(
      '[ensurePerms] notifications not granted and blockingMode=true -> aborting',
    );
    await prefs.setBool('last_required_perms_notifications', notificationsOk);
    await prefs.setBool('last_required_perms_exactalarm', false);
    return false;
  }

  await _handleExactAlarmPermission();

  await prefs.setBool('last_required_perms_notifications', notificationsOk);
  await prefs.setBool('last_required_perms_exactalarm', exactAlarmOk);

  final allOk = notificationsOk && exactAlarmOk;
  debugPrint(
    '[ensurePerms] final -> notifications:$notificationsOk exactAlarm:$exactAlarmOk',
  );

  return allOk;
}

Future<void> _maybeShowUpgradeIfNeeded() async {
  try {
    try {
      // best-effort: call method if available
      await PurchaseManager.instance.checkTrialAndNotifyIfExpired();
    } catch (_) {
      debugPrint(
        '[main] PurchaseManager.checkTrialAndMarkIfExpired not available or failed silently',
      );
    }

    final prefs = await SharedPreferences.getInstance();
    final shouldShow = prefs.getBool(_kPrefsShowUpgradeOnLaunch) ?? false;
    debugPrint(
      '[main] _maybeShowUpgradeIfNeeded -> shouldShow=$shouldShow sessionShown=$_upgradePromptShownThisSession',
    );

    if (!shouldShow) return;
    if (_upgradePromptShownThisSession) return;

    // clear the flag so it won't show again on next startup
    await prefs.setBool(_kPrefsShowUpgradeOnLaunch, false);

    // Cancel subscription reminders to avoid sending notifications while user sees the upgrade page
    try {
      await NotificationsService.instance.cancelDailySubscriptionReminder(
        markCancelled: true,
      );
    } catch (e) {
      debugPrint('[main] cancelDailySubscriptionReminder failed -> $e');
    }

    final nav = gNavigatorKey;
    final ctx = nav.currentState?.overlay?.context;
    if (ctx == null) {
      debugPrint(
        '[main] navigator context not available, cannot show UpgradePromptPage now',
      );
      return;
    }

    // mark shown this session and push the page
    _upgradePromptShownThisSession = true;
    nav.currentState?.push(
      MaterialPageRoute(builder: (_) => const UpgradePromptPage()),
    );
    debugPrint('[main] UpgradePromptPage pushed');
  } catch (e, st) {
    debugPrint('[main] _maybeShowUpgradeIfNeeded error -> $e\n$st');
  }
}

class MyApp extends StatelessWidget {
  final GlobalKey<NavigatorState> navigatorKey;

  const MyApp({super.key, required this.navigatorKey});

  Future<bool> hasSettings() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('workSystem') && prefs.containsKey('startDate');
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'Work Reminder App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: FutureBuilder<bool>(
        future: hasSettings(),
        builder: (context, snapshot) {
          if (!snapshot.hasData)
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          return snapshot.data == true
              ? const CalendarLauncher()
              : const SettingsPage();
        },
      ),
    );
  }
}

class CalendarLauncher extends StatefulWidget {
  const CalendarLauncher({super.key});

  @override
  State<CalendarLauncher> createState() => _CalendarLauncherState();
}

class _CalendarLauncherState extends State<CalendarLauncher>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    debugPrint('[CalendarLauncher] observer added');

    // Also try to show upgrade prompt after first frame inside this page (safety net)
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _maybeShowUpgradeIfNeeded();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    debugPrint('[CalendarLauncher] observer removed');
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    debugPrint('[CalendarLauncher] lifecycle changed -> $state');
    if (state == AppLifecycleState.resumed) {
      NotificationsService.instance.onAppResumed();
      // refresh subscriptions state from backend when app resumes
      PurchaseManager.instance.refreshFromBackend();

      // re-check trial and show upgrade if needed when returning to app
      _maybeShowUpgradeIfNeeded();
    }
  }

  // (generateWorkSchedule kept as in your original code — unchanged)
  Map<DateTime, String> generateWorkSchedule(
      String system,
      DateTime startDate,
      int maintenanceInterval,
      ) {
    final schedule = <DateTime, String>{};
    int shiftCounter = 0;
    String lastShift = "راحة";
    bool isFirstShift = true;
    for (int i = 0; i < 3650; i++) {
      final dayLocal = startDate.add(Duration(days: i));
      String shift = "راحة";

      if (system == 'نظام العمل 12/24-12/48') {
        final cycle = i % 4;
        if (cycle == 0) shift = "صبح";
        if (cycle == 1) shift = "ليل";
      } else if (system == 'نظام العمل يوم عمل - يومين راحة') {
        shift = (i % 3 == 0) ? "صبح" : "راحة";
      } else if (system == 'يومين عمل ٤ أيام راحة') {
        final cycle = i % 6;
        if (cycle == 0 || cycle == 1) shift = "صبح";
      } else if (system == '3 أيام عمل (صبح - عصر - ليل) يليها يومين راحة') {
        final cycle = i % 5;
        if (cycle == 0) shift = "صبح";
        if (cycle == 1) shift = "عصر";
        if (cycle == 2) shift = "ليل";
      } else if (system == '6 أيام عمل 2 يوم راحة') {
        final cycle = i % 8;
        if (cycle == 0 || cycle == 1) shift = "صبح";
        if (cycle == 2 || cycle == 3) shift = "عصر";
        if (cycle == 4 || cycle == 5) shift = "ليل";
      } else if (system == 'صباحي') {
        final weekday = dayLocal.weekday;
        shift = (weekday >= 1 && weekday <= 5) ? "صبح" : "راحة";
      }

      if (shift != "راحة" && lastShift == "راحة") {
        shiftCounter++;
        if (isFirstShift && maintenanceInterval > 0) {
          shift = "صيانة";
          isFirstShift = false;
        } else {
          if (maintenanceInterval > 0 &&
              shiftCounter > 1 &&
              (shiftCounter - 1) % maintenanceInterval == 0) {
            shift = "صيانة";
          }
        }
      } else if (shift != "راحة" && lastShift != "راحة") {
        if (lastShift == "صيانة") shift = "صيانة";
      }

      final keyUtc = DateTime.utc(dayLocal.year, dayLocal.month, dayLocal.day);
      schedule[keyUtc] = shift;
      lastShift = shift;
    }
    return schedule;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<SharedPreferences>(
      future: SharedPreferences.getInstance(),
      builder: (context, snapshot) {
        if (!snapshot.hasData)
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        final prefs = snapshot.data!;
        final startDateStr = prefs.getString('startDate');
        final system = prefs.getString('workSystem') ?? '';
        final maintenanceInterval = prefs.getInt('maintenanceInterval') ?? 0;
        if (startDateStr == null || system.isEmpty) return const SettingsPage();

        final parsed = DateTime.tryParse(startDateStr);
        if (parsed == null) return const SettingsPage();
        final startDate = DateTime(parsed.year, parsed.month, parsed.day);
        final schedule = generateWorkSchedule(
          system,
          startDate,
          maintenanceInterval,
        );
        return CalendarPage(
          schedule: schedule,
          morningColor: Color(prefs.getInt('morningColor') ?? Colors.red.value),
          afternoonColor: Color(
            prefs.getInt('afternoonColor') ?? Colors.orange.value,
          ),
          nightColor: Color(prefs.getInt('nightColor') ?? Colors.blue.value),
          restColor: Color(prefs.getInt('restColor') ?? Colors.green.value),
          maintenanceColor: Color(
            prefs.getInt('maintenanceColor') ?? Colors.purple.value,
          ),
        );
      },
    );
  }
}

/// Small widget used in settings - kept here for convenience if you referenced it earlier.
class ExactAlarmsWidget extends StatefulWidget {
  const ExactAlarmsWidget({super.key});

  @override
  State<ExactAlarmsWidget> createState() => _ExactAlarmsWidgetState();
}

class _ExactAlarmsWidgetState extends State<ExactAlarmsWidget> {
  bool _enabled = true;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPref();
  }

  Future<void> _loadPref() async {
    final prefs = await SharedPreferences.getInstance();
    final disabled = prefs.getBool('disable_exact_alarms') ?? false;
    setState(() {
      _enabled = !disabled;
      _loading = false;
    });
  }

  Future<void> _toggle(bool val) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('disable_exact_alarms', !val);
    setState(() => _enabled = val);
    if (!val) {
      try {
        await NotificationsService.instance.cancelAll();
      } catch (e) {
        debugPrint('[ExactAlarmsWidget] cancelAll failed -> $e');
      }
    } else {
      try {
        await NotificationsService.instance.rescheduleIfNeeded(force: false);
      } catch (e) {
        debugPrint('[ExactAlarmsWidget] rescheduleIfNeeded failed -> $e');
      }
    }
  }

  Future<void> _disableCompletely() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('disable_exact_alarms', true);
    setState(() => _enabled = false);
    try {
      await NotificationsService.instance.cancelAll();
    } catch (e) {
      debugPrint('[ExactAlarmsWidget] cancelAll failed -> $e');
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'تم تعطيل التنبيهات الدقيقة وإلغاء كل الإشعارات المجدولة.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'تنبيهات دقيقة',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Switch(value: _enabled, onChanged: (v) => _toggle(v)),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'تتحكم هذه الخاصية في إمكانية الجدولة بدقة (exact alarms). '
                  'تعطيلها يمنع بعض الإشعارات الدقيقة أثناء Doze، وسيتم إلغاء الجداول المجدولة.',
              textAlign: TextAlign.right,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _disableCompletely,
              child: const Text('شلها خالص (تعطيل وإلغاء الكل)'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
          ],
        ),
      ),
    );
  }
}
